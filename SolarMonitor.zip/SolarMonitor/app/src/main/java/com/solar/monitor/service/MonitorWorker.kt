package com.solar.monitor.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.solar.monitor.R
import com.solar.monitor.model.SolarData
import com.solar.monitor.model.SolarParser
import com.solar.monitor.ui.MainActivity
import com.solar.monitor.widget.SolarWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class MonitorWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        const val CHANNEL_ALERT = "solar_alerts"
        const val CHANNEL_INFO  = "solar_info"
        const val NOTIF_ID_ALERT = 1001
        const val NOTIF_ID_INFO  = 1002
        private const val TAG = "MonitorWorker"
        const val SOLAR_URL = "https://solcloudy.com/62086746225886f8f4d914b29cb3f4/"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        createNotificationChannels()

        val prefs = applicationContext.getSharedPreferences("solar_prefs", Context.MODE_PRIVATE)
        val batteryThreshold = prefs.getInt("battery_threshold", 20)
        val notifyNoSolar = prefs.getBoolean("notify_no_solar", true)

        try {
            val html = fetchPage() ?: return@withContext Result.retry()
            val data = SolarParser.parse(html) ?: return@withContext Result.retry()

            Log.d(TAG, "Fetched: solar=${data.solarPowerW}W bat=${data.batteryPercent}%")

            // Save last data for widget
            saveDataForWidget(data)

            // Update widget
            SolarWidget.updateAll(applicationContext, data)

            // Check alerts
            checkAndNotify(data, batteryThreshold, notifyNoSolar)

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Worker error: ${e.message}")
            Result.retry()
        }
    }

    private fun fetchPage(): String? {
        return try {
            val req = Request.Builder().url(SOLAR_URL).build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) resp.body?.string() else null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fetch error: ${e.message}")
            null
        }
    }

    private fun saveDataForWidget(data: SolarData) {
        applicationContext.getSharedPreferences("widget_data", Context.MODE_PRIVATE).edit().apply {
            putFloat("solar_w",    data.solarPowerW.toFloat())
            putFloat("grid_w",     data.gridPowerW.toFloat())
            putFloat("load_w",     data.loadPowerW.toFloat())
            putInt("battery_pct",  data.batteryPercent)
            putFloat("bat_v",      data.batteryVoltageV.toFloat())
            putLong("timestamp",   data.timestamp)
            apply()
        }
    }

    private fun checkAndNotify(data: SolarData, batteryThreshold: Int, notifyNoSolar: Boolean) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Critical: battery low + no grid
        if (data.hasCriticalIssue()) {
            sendAlert(nm, "⚠️ Критична ситуація!",
                "Батарея ${data.batteryPercent}% і немає мережі. Потужність навантаження: ${data.loadPowerW.toInt()} W")
            return
        }

        // Battery below threshold
        if (data.isBatteryLow() && data.batteryPercent <= batteryThreshold) {
            sendAlert(nm, "🔋 Низький заряд батареї",
                "Заряд батареї: ${data.batteryPercent}% (${data.batteryVoltageV} V)")
            return
        }

        // Solar panels not producing during daylight
        if (notifyNoSolar && data.isSolarOffDuringDay()) {
            sendAlert(nm, "☀️ Панелі не виробляють енергію",
                "Сонячне випромінювання ${data.irradianceWm2.toInt()} W/m² але панелі виробляють лише ${data.solarPowerW.toInt()} W")
        }
    }

    private fun sendAlert(nm: NotificationManager, title: String, message: String) {
        val intent = Intent(applicationContext, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(applicationContext, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_solar_panel)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        nm.notify(NOTIF_ID_ALERT, notif)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_ALERT, "Сповіщення про проблеми",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Критичні сповіщення про стан інвертора" })

            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_INFO, "Інформаційні сповіщення",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Щоденна статистика" })
        }
    }
}
