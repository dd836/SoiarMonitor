package com.solar.monitor.model

import android.util.Log
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

object SolarParser {

    private const val TAG = "SolarParser"

    fun parse(html: String): SolarData? {
        return try {
            val doc: Document = Jsoup.parse(html)
            val data = SolarData(
                solarPowerW  = extractValue(doc, "solar", "W"),
                gridPowerW   = extractValue(doc, "grid", "W"),
                loadPowerW   = extractValue(doc, "load", "W"),
                batteryVoltageV  = extractValue(doc, "battery", "V"),
                batteryPercent   = extractValue(doc, "battery", "%").toInt(),
                batteryCurrentA  = extractValue(doc, "battery", "A"),
                gridVoltageV     = extractValue(doc, "grid", "V"),
                gridFrequencyHz  = extractValue(doc, "grid", "Hz"),
                temperatureC     = extractValue(doc, "temperature", "°C"),
                irradianceWm2    = extractValue(doc, "irradiance", "W/m"),
                todayKwh         = extractValue(doc, "today", "kWh")
            )
            Log.d(TAG, "Parsed: solar=${data.solarPowerW}W bat=${data.batteryPercent}%")
            data
        } catch (e: Exception) {
            Log.e(TAG, "Parse error: ${e.message}")
            null
        }
    }

    /**
     * Extracts numeric value from the page.
     * solcloudy.com renders data in elements like:
     *   <div class="value">1475.3 W</div>  or  <td>1475.3 W</td>
     * Strategy: find all text nodes containing the unit, grab the number closest to the keyword.
     */
    private fun extractValue(doc: Document, keyword: String, unit: String): Double {
        // Try structured data attributes first (some inverter pages use data-*)
        val byAttr = doc.select("[data-key*=$keyword]").firstOrNull()
        if (byAttr != null) {
            return parseNumber(byAttr.text())
        }

        // Search in table rows: find row whose label contains keyword
        val rows = doc.select("tr, .param-row, .data-row")
        for (row in rows) {
            val cells = row.select("td, th, .label, .value")
            if (cells.size >= 2) {
                val label = cells[0].text().lowercase()
                val value = cells[1].text()
                if (label.contains(keyword.lowercase()) && value.contains(unit, ignoreCase = true)) {
                    return parseNumber(value)
                }
            }
        }

        // Fallback: find any element containing both the unit text
        val elements = doc.select("*:containsOwn($unit)")
        for (el in elements) {
            val text = el.text()
            val num = parseNumber(text)
            if (num > 0) return num
        }

        return 0.0
    }

    private fun parseNumber(text: String): Double {
        return try {
            val cleaned = text.replace(Regex("[^0-9.,\\-]"), "")
                .replace(",", ".")
                .trim()
            if (cleaned.isEmpty()) 0.0 else cleaned.toDouble()
        } catch (e: NumberFormatException) {
            0.0
        }
    }
}
