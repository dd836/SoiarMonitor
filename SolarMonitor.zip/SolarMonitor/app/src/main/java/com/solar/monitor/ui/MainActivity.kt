package com.solar.monitor.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.*
import com.solar.monitor.R
import com.solar.monitor.databinding.ActivityMainBinding
import com.solar.monitor.service.MonitorWorker
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val SOLAR_URL = "https://solcloudy.com/62086746225886f8f4d914b29cb3f4/"

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scheduleMonitoring()
        else Toast.makeText(this, getString(R.string.notif_permission_denied), Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)

        setupWebView()
        setupSwipeRefresh()
        requestNotificationPermission()
        loadPage()
    }

    private fun setupWebView() {
        with(binding.webView) {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                loadsImagesAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
            }

            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.offlineLayout.visibility = View.GONE
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    binding.progressBar.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    // Inject CSS to improve mobile display
                    injectMobileStyles()
                }

                override fun onReceivedError(
                    view: WebView?, request: WebResourceRequest?, error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        binding.progressBar.visibility = View.GONE
                        binding.swipeRefresh.isRefreshing = false
                        if (!isNetworkAvailable()) {
                            binding.offlineLayout.visibility = View.VISIBLE
                        }
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    if (newProgress < 100) {
                        binding.progressBar.progress = newProgress
                    }
                }
            }
        }

        binding.btnRetry.setOnClickListener { loadPage() }
    }

    private fun injectMobileStyles() {
        val css = """
            body { font-size: 16px !important; }
            .container, .wrapper, main { max-width: 100% !important; padding: 8px !important; }
            table { width: 100% !important; }
            .card, .panel, .box { margin: 4px !important; }
        """.trimIndent().replace("\n", " ")

        binding.webView.evaluateJavascript(
            """(function(){
                var s=document.createElement('style');
                s.innerHTML='$css';
                document.head.appendChild(s);
            })();""", null
        )
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setColorSchemeResources(
            R.color.solar_yellow,
            R.color.solar_green,
            R.color.solar_blue
        )
        binding.swipeRefresh.setOnRefreshListener { loadPage() }
    }

    private fun loadPage() {
        if (isNetworkAvailable()) {
            binding.offlineLayout.visibility = View.GONE
            binding.webView.loadUrl(SOLAR_URL)
        } else {
            binding.offlineLayout.visibility = View.VISIBLE
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED -> scheduleMonitoring()
                else -> notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            scheduleMonitoring()
        }
    }

    private fun scheduleMonitoring() {
        val prefs = getSharedPreferences("solar_prefs", MODE_PRIVATE)
        val intervalMin = prefs.getInt("check_interval_min", 5).toLong()

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val work = PeriodicWorkRequestBuilder<MonitorWorker>(intervalMin, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .addTag("solar_monitor")
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "solar_check",
            ExistingPeriodicWorkPolicy.UPDATE,
            work
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> { loadPage(); true }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
