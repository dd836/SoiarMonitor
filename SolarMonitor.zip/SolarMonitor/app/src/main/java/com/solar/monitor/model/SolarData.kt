package com.solar.monitor.model

data class SolarData(
    val solarPowerW: Double = 0.0,
    val gridPowerW: Double = 0.0,
    val loadPowerW: Double = 0.0,
    val batteryVoltageV: Double = 0.0,
    val batteryPercent: Int = 0,
    val batteryCurrentA: Double = 0.0,
    val gridVoltageV: Double = 0.0,
    val gridFrequencyHz: Double = 0.0,
    val temperatureC: Double = 0.0,
    val irradianceWm2: Double = 0.0,
    val todayKwh: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun isOnline() = solarPowerW > 5 || gridPowerW > 0
    fun hasCriticalIssue() = batteryPercent < 20 && gridPowerW < 10
    fun isBatteryLow() = batteryPercent in 1..29
    fun isSolarOffDuringDay() = solarPowerW < 5 && irradianceWm2 > 100
}
