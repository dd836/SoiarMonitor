package com.solar.monitor.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.*
import java.util.concurrent.TimeUnit

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("solar_prefs", Context.MODE_PRIVATE)
            val interval = prefs.getInt("check_interval_min", 5).toLong()

            val work = PeriodicWorkRequestBuilder<MonitorWorker>(interval, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build())
                .addTag("solar_monitor")
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "solar_check",
                ExistingPeriodicWorkPolicy.UPDATE,
                work
            )
        }
    }
}
