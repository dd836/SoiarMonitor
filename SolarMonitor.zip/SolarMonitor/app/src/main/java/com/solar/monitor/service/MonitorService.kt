package com.solar.monitor.service

import android.app.Service
import android.content.Intent
import android.os.IBinder

// Placeholder foreground service — actual monitoring is via WorkManager (MonitorWorker)
class MonitorService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf()
        return START_NOT_STICKY
    }
}
