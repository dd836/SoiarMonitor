package com.solar.monitor.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.solar.monitor.R
import com.solar.monitor.model.SolarData
import com.solar.monitor.ui.MainActivity
import java.text.SimpleDateFormat
import java.util.*

class SolarWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray
    ) {
        val prefs = context.getSharedPreferences("widget_data", Context.MODE_PRIVATE)
        val data = SolarData(
            solarPowerW   = prefs.getFloat("solar_w", 0f).toDouble(),
            gridPowerW    = prefs.getFloat("grid_w", 0f).toDouble(),
            loadPowerW    = prefs.getFloat("load_w", 0f).toDouble(),
            batteryPercent = prefs.getInt("battery_pct", 0),
            batteryVoltageV = prefs.getFloat("bat_v", 0f).toDouble(),
            timestamp     = prefs.getLong("timestamp", 0)
        )
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id, data)
        }
    }

    companion object {
        fun updateAll(context: Context, data: SolarData) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, SolarWidget::class.java))
            for (id in ids) updateWidget(context, mgr, id, data)
        }

        private fun updateWidget(
            context: Context, mgr: AppWidgetManager, widgetId: Int, data: SolarData
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_solar)

            views.setTextViewText(R.id.widget_solar_power,  "☀️ ${data.solarPowerW.toInt()} W")
            views.setTextViewText(R.id.widget_load_power,   "🏠 ${data.loadPowerW.toInt()} W")
            views.setTextViewText(R.id.widget_grid_power,   "🔌 ${data.gridPowerW.toInt()} W")
            views.setTextViewText(R.id.widget_battery,      "🔋 ${data.batteryPercent}%")
            views.setTextViewText(R.id.widget_bat_voltage,  "${data.batteryVoltageV} V")

            val timeStr = if (data.timestamp > 0) {
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(data.timestamp))
            } else "--:--"
            views.setTextViewText(R.id.widget_updated, "Оновлено: $timeStr")

            // Battery color indicator
            val batteryColor = when {
                data.batteryPercent >= 60 -> 0xFF4CAF50.toInt() // green
                data.batteryPercent >= 30 -> 0xFFFFC107.toInt() // amber
                else -> 0xFFF44336.toInt() // red
            }
            views.setInt(R.id.widget_battery, "setTextColor", batteryColor)

            // Click opens app
            val intent = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)

            mgr.updateAppWidget(widgetId, views)
        }
    }
}
